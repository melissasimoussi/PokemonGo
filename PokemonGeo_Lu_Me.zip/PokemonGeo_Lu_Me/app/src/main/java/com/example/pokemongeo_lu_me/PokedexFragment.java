package com.example.pokemongeo_lu_me;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.pokemongeo_lu_me.databinding.PokedexFragmentBinding;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.*;
import java.io.*;

public class PokedexFragment extends Fragment {

    public PokedexFragment() {};
    List<Pokemon> pokemonList = new ArrayList<>();

    public List<Pokemon> getPokemonList() {
        pokemonList.add(poke1);
        pokemonList.add(poke2);
        return pokemonList;
    }

    Pokemon poke1 = new Pokemon(1,"Greslé",R.drawable.p1,POKEMON_TYPE.Plante,POKEMON_TYPE.Eau);
    Pokemon poke2 = new Pokemon(2,"Hauet",R.drawable.p3,POKEMON_TYPE.Roche,POKEMON_TYPE.Feu);



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        PokedexFragmentBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.pokedex_fragment,container,false);
        binding.pokemonList.setLayoutManager(new LinearLayoutManager(
                binding.getRoot().getContext()));
        getPokemonList();
        PokemonListAdapter adapter = new PokemonListAdapter(pokemonList);
        binding.pokemonList.setAdapter(adapter);
        return binding.getRoot();

    }

}
package com.example.pokemongeo_lu_me;

public enum POKEMON_TYPE {
    Acier,
    Combat,
    Dragon,
    Eau,
    Electrique,
    Fee,
    Feu,
    Glace,
    Insecte,
    Normal,
    Plante,
    Poison,
    Psy,
    Roche,
    Sol,
    Spectre,
    Tenebre,
    Vol
}
